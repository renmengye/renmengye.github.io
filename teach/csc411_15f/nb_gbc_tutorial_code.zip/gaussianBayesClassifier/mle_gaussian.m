function [mu,Sigma] = mle_gaussian(data)

% maximum likelihood estimation of a multivariate Gaussian

N = size(data,2);
mu = mean(data')';
Sigma = cov(data');

