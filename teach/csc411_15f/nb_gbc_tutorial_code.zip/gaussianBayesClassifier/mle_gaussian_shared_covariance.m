function [mu,Sigma] = mle_gaussian_shared_covariance(data, labels)

% maximum likelihood estimation of a multivariate Gaussian per class with
% share covariance

N = size(data,2);
d = size(data,1);
K = max(labels)+1;
mu = zeros(d,K);
acc=zeros(d,d);

% compute means for each class
for i=0:K-1
    index = find(labels==i);
    mu(:,i+1) = mean(data(:,index)')';
    N_class = length(index);
    vector_mean = data(:,index)- repmat(mu(:,i+1),1,N_class);
    acc = acc + (vector_mean*vector_mean')';
end

Sigma = acc/N;