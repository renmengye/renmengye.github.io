% gbc_demo
close all;
rng(1.0);

X_MAX = 50;
Y_MAX = 50;
NUM_TRAIN = 100;
RANDOM_LABELS = 0;

%-------------------------------------------------------------
% Generate the test points coming from a Gaussian distribution
%-------------------------------------------------------------

mu_1 = [1 1];
mu_2 = [-2 0];
sigma1 = [1 -1; -1, 4];
sigma2 = [4 2; 2, 2];
% sigma1 = [1 -0.5; -0.5, 4];
% sigma2 = [4 0.5; 0.5, 2];
d = size(mu_1,2);

%-------------------------------------------------------------
% Generate random training points.
%-------------------------------------------------------------

data_train = [mvnrnd(mu_1,sigma1,NUM_TRAIN/2)', mvnrnd(mu_2,sigma2,NUM_TRAIN/2)'];
label_train = [zeros(1,NUM_TRAIN/2), ones(1,NUM_TRAIN/2)];
%data_train = mvnrnd(mu_2,sigma,NUM_TRAIN);

figure(1)
clf;
plot_train(data_train,label_train);
xlabel('x1','fontsize',16); ylabel('x2','fontsize',16);
title('Training Examples','fontsize',16);

pause;

%-------------------------------------------------------------
% Plot Gaussian Distribution
%-------------------------------------------------------------

figure(2);
x1 = -6:.2:6; x2 = -3:.2:6;
[X1,X2] = meshgrid(x1,x2);
F = mvnpdf([X1(:) X2(:)],mu_1,sigma1);
F = reshape(F,length(x2),length(x1));
surf(x1,x2,F);
caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
axis([-5 6 -3 6 0 .2])
xlabel('x1','fontsize',16); ylabel('x2','fontsize',16); zlabel('Probability Density of t=0','fontsize',16);

pause;

figure(3)
x1 = -6:.2:6; x2 = -3:.2:6;
[X1,X2] = meshgrid(x1,x2);
F = mvnpdf([X1(:) X2(:)],mu_2,sigma2);
F = reshape(F,length(x2),length(x1));
surf(x1,x2,F);
caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
axis([-5 6 -3 6 0 .2])
xlabel('x1','fontsize',16); ylabel('x2','fontsize',16); zlabel('Probability Density of t=1','fontsize',16);

pause;

%-------------------------------------------------------------
% Do Maximimum Likelihood Estimation with different assumptions
%-------------------------------------------------------------

% do independent estimation
[mu_est_1, Sigma_est_1] = mle_gaussian(data_train(:,find(label_train==0)));
[mu_est_2, Sigma_est_2] = mle_gaussian(data_train(:,find(label_train==1)));

% plot results of independent estimation
x1 = -8:.2:6; x2 = -6:.2:6;
[X1,X2] = meshgrid(x1,x2);
p1 = mvnpdf([X1(:) X2(:)],mu_est_1',Sigma_est_1);
p2 = mvnpdf([X1(:) X2(:)],mu_est_2',Sigma_est_2);
figure(4);
clf;
[p_max,index_m] = max([p1 ,p2]');
plot_train(data_train,label_train);
plot_test([X1(:) X2(:)]', index_m-1);
title('Independent prediction Full Covariance','fontsize',16);
pause;


% plot results of joint estimation
[mu_est_joint, Sigma_est_joint] = mle_gaussian_shared_covariance(data_train, label_train);

figure(5);
clf;
p1 = mvnpdf([X1(:) X2(:)],mu_est_joint(:,1)',Sigma_est_joint);
p2 = mvnpdf([X1(:) X2(:)],mu_est_joint(:,2)',Sigma_est_joint);
[p_max,index_m] = max([p1 ,p2]');
plot_train(data_train,label_train);
plot_test([X1(:) X2(:)]', index_m-1);
title('Shared Full Covariance','fontsize',16);
pause;


%%% naive Bayes
% the mean is the same as the joint estimation
% the covariance is now independent for each dimension
sigma_naive = diag(var(data_train'));


figure(6);
clf;
p1 = mvnpdf([X1(:) X2(:)],mu_est_joint(:,1)',sigma_naive);
p2 = mvnpdf([X1(:) X2(:)],mu_est_joint(:,2)',sigma_naive);
[p_max,index_m] = max([p1 ,p2]');
plot_train(data_train,label_train);
plot_test([X1(:) X2(:)]', index_m-1);
title('Naive Bayes with Share Variance','fontsize',16);
pause;



% mu_1, mu_2
% mu_est_1
% mu_est_2
% mu_est_joint
% 
% pause;
% 
% sigma_1
% sigma_2
% Sigma_est_1
% Sigma_est_2
% Sigma_est_joint





close all;
clear all;
