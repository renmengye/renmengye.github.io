function [pcond, prior] = nb(x, t)

[numcases, numattr] = size(x);
numclass = max(t) - min(t) + 1;

pcond = zeros(numclass, numattr);
prior = zeros(1, numclass);

for i = 1 : numclass
    s = (t == i + min(t) - 1);
    numinstance = sum(s);       %the total number of examples with label i
    prior(i) = numinstance / numcases;
    xc = x(s, :);
    pcond(i, :) = sum(xc) / numinstance;
end

return
end
