function topwords(p, k, dict, istop)

if istop
    [prob, idx] = sort(p, 'descend');
else
    [prob, idx] = sort(p, 'ascend');
end

fprintf('Cond Prob\tWord\n-----------------------------\n');
for i = 1 : k
    fprintf('%.4f\t\t%s\n', prob(i), dict{idx(i)});
end
fprintf('\n')

return
end
